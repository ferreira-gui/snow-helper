/* SNOW Helper — service worker para atalhos e lembretes por ticket. */
'use strict';

var REMINDER_PREFIX='snow-helper-reminder:';

function getReminders(done){
  chrome.storage.local.get({shReminders:{}},function(data){
    done(data.shReminders&&typeof data.shReminders==='object'?data.shReminders:{});
  });
}
function saveReminders(reminders,done){
  chrome.storage.local.set({shReminders:reminders},function(){if(done)done();});
}
function alarmName(ticket){return REMINDER_PREFIX+ticket;}
function activatePanel(tab,tabName,done){
  if(!tab||!tab.id){if(done)done();return;}
  chrome.tabs.sendMessage(tab.id,{type:'snow-helper:open-panel',tab:tabName||'templates'},function(){
    // A página pode ainda não ter o content script; o atalho permanece seguro.
    if(done)done();
  });
}

chrome.commands.onCommand.addListener(function(command){
  if(command!=='toggle-panel')return;
  chrome.tabs.query({active:true,lastFocusedWindow:true},function(tabs){
    activatePanel(tabs[0],'templates');
  });
});

chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
  if(!message||typeof message.type!=='string')return;
  if(message.type==='snow-helper:set-reminder'){
    var ticket=String(message.ticket||'').slice(0,140);
    var delay=Math.max(1,Number(message.delay)||30);
    if(!ticket){sendResponse({ok:false});return;}
    var reminder={
      ticket:ticket,
      number:String(message.number||ticket),
      user:String(message.user||''),
      url:String(message.url||''),
      when:Date.now()+delay*60*1000
    };
    getReminders(function(reminders){
      reminders[ticket]=reminder;
      chrome.alarms.create(alarmName(ticket),{when:reminder.when});
      saveReminders(reminders,function(){sendResponse({ok:true,reminder:reminder});});
    });
    return true;
  }
  if(message.type==='snow-helper:clear-reminder'){
    var clearTicket=String(message.ticket||'').slice(0,140);
    chrome.alarms.clear(alarmName(clearTicket),function(){
      getReminders(function(reminders){
        delete reminders[clearTicket];
        saveReminders(reminders,function(){sendResponse({ok:true});});
      });
    });
    return true;
  }
  if(message.type==='snow-helper:get-reminder'){
    var lookupTicket=String(message.ticket||'').slice(0,140);
    getReminders(function(reminders){sendResponse({ok:true,reminder:reminders[lookupTicket]||null});});
    return true;
  }
});

chrome.alarms.onAlarm.addListener(function(alarm){
  if(alarm.name.indexOf(REMINDER_PREFIX)!==0)return;
  var ticket=alarm.name.slice(REMINDER_PREFIX.length);
  getReminders(function(reminders){
    var reminder=reminders[ticket];
    if(!reminder)return;
    delete reminders[ticket];
    saveReminders(reminders);
    var title='SNOW Helper · aguardando usuário';
    var message=(reminder.number||ticket)+(reminder.user?' · '+reminder.user:'')+' precisa de acompanhamento.';
    chrome.notifications.create(alarm.name,{
      type:'basic',
      iconUrl:'icons/icon128.png',
      title:title,
      message:message,
      priority:1
    });
  });
});

chrome.notifications.onClicked.addListener(function(notificationId){
  if(notificationId.indexOf(REMINDER_PREFIX)!==0)return;
  var ticket=notificationId.slice(REMINDER_PREFIX.length);
  getReminders(function(reminders){
    // A entrada normalmente já foi removida após disparar; esta leitura mantém
    // compatibilidade com versões do Chrome que acionam o clique antes da gravação.
    var reminder=reminders[ticket];
    if(reminder&&reminder.url){chrome.tabs.create({url:reminder.url});}
  });
});
