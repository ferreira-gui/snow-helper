(function(){
'use strict';
if(window.top!==window.self)return;
['snow-helper-root','snowhelper15-root','snowhelper16-root','snowhelper17-root',
 'snowhelper18-root','snowhelper19-root','snowhelper19-ai',
 'sh19-modal','sh19-toast','sh19-settings','sh19-clockstyle'].forEach(function(id){
  var e=document.getElementById(id); if(e)e.remove();
});
if(document.getElementById('snowhelper19-root'))return;

var norm=function(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()};

var styleEl=document.createElement('style');
styleEl.id='sh19-clockstyle';
styleEl.textContent=[
'#sh19-clock{',
'  display:none;align-items:center;gap:6px;',
'  padding:5px 10px;border-radius:9px;',
'  background:linear-gradient(135deg,var(--acc-wash,#eef2ff) 0%,var(--bg-soft,#f8fafc) 100%);',
'  border:1px solid var(--bd,#e2e8f0);',
'  font-size:12.5px;font-weight:600;color:var(--text,#0f172a);',
'  font-family:ui-monospace,"JetBrains Mono",Consolas,monospace;',
'  flex:0 0 auto;margin-left:auto;margin-right:6px;',
'  cursor:default;user-select:none;',
'  transition:all .2s;',
'}',
'#sh19-clock.on{display:inline-flex}',
'#sh19-clock .clock-ico{opacity:.7;font-size:11px;line-height:1}',
'#sh19-clock b{color:var(--acc-deep,#4338ca);font-weight:800;font-variant-numeric:tabular-nums;letter-spacing:-.01em}',
'#sh19-clock .clock-day{color:var(--text-soft,#475569);font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em}',
'#sh19-clock .clock-flag{font-size:14px;line-height:1}'
].join('');
document.head.appendChild(styleEl);

var CATS = {
  all:{es:'Todas',pt:'Todas',en:'All'},
  apertura:{es:'Apertura',pt:'Abertura',en:'Opening'},
  info:{es:'Info',pt:'Info',en:'Info'},
  seguimiento:{es:'Seguimiento',pt:'Acompanhamento',en:'Follow-up'},
  escalado:{es:'Escalado',pt:'Escalação',en:'Escalation'},
  cierre:{es:'Cierre',pt:'Encerramento',en:'Closing'},
  llamada:{es:'Llamada',pt:'Chamada',en:'Call'}
};

var BUILTIN_TEMPLATES = [
 {id:'contacto-inicial',cat:'apertura',
  es:{title:'Contacto inicial',body:'{saludo} {nombre|estimado/a usuario/a}:\n\nLe contactamos en relación con la incidencia {numero}. ¿Puede confirmar si está disponible para realizar algunas comprobaciones?\n\nUn saludo,\n{tecnico} · Service Desk ACCIONA'},
  pt:{title:'Contato inicial',body:'{saludo} {nombre|prezado(a) usuário(a)}:\n\nEntramos em contato a respeito do incidente {numero}. Pode confirmar se está disponível para realizarmos algumas verificações?\n\nAtenciosamente,\n{tecnico} · Service Desk ACCIONA'},
  en:{title:'Initial contact',body:'{saludo} {nombre|dear user}:\n\nWe are contacting you regarding incident {numero}. Could you confirm if you are available to perform some checks?\n\nBest regards,\n{tecnico} · ACCIONA Service Desk'}},
 {id:'toma-contacto',cat:'apertura',
  es:{title:'Toma de contacto / Ticket abierto',body:'{saludo} {nombre|estimado/a usuario/a}:\n\nHemos recibido su incidencia {numero} y ya está asignada a nuestro equipo. Estamos revisando el caso y le mantendremos informado.\n\nGracias por su paciencia.\n{tecnico} · Service Desk ACCIONA'},
  pt:{title:'Tomada de contato / Ticket aberto',body:'{saludo} {nombre|prezado(a) usuário(a)}:\n\nRecebemos o seu incidente {numero} e já está atribuído à nossa equipe. Estamos a analisar o caso e manteremos você informado.\n\nObrigado pela sua paciência.\n{tecnico} · Service Desk ACCIONA'},
  en:{title:'Ticket received / Open',body:'{saludo} {nombre|dear user}:\n\nWe have received your incident {numero} and it is already assigned to our team. We are reviewing the case and will keep you informed.\n\nThank you for your patience.\n{tecnico} · ACCIONA Service Desk'}},
 {id:'diag-red',cat:'info',
  es:{title:'Solicitar diagnósticos de red',body:'{saludo} {nombre|estimado/a usuario/a}:\n\nPara avanzar con la incidencia {numero}, necesitamos que nos envíe:\n\n· ipconfig /all\n· ping (destino)\n· tracert (destino)\n· captura del error\n\nGracias.\n{tecnico} · Service Desk ACCIONA'},
  pt:{title:'Solicitar diagnósticos de rede',body:'{saludo} {nombre|prezado(a) usuário(a)}:\n\nPara avançar com o incidente {numero}, precisamos que nos envie:\n\n· ipconfig /all\n· ping (destino)\n· tracert (destino)\n· print do erro\n\nObrigado.\n{tecnico} · Service Desk ACCIONA'},
  en:{title:'Request network diagnostics',body:'{saludo} {nombre|dear user}:\n\nTo progress with incident {numero}, we need you to send us:\n\n· ipconfig /all\n· ping (target)\n· tracert (target)\n· screenshot of the error\n\nThank you.\n{tecnico} · ACCIONA Service Desk'}},
 {id:'mas-datos',cat:'info',
  es:{title:'Solicitar más datos del caso',body:'{saludo} {nombre|estimado/a usuario/a}:\n\nPara continuar con la incidencia {numero} necesitamos que nos amplíe la siguiente información:\n\n· Descripción exacta del error\n· Cuándo empezó a ocurrir\n· Si afecta a más compañeros\n· Capturas de pantalla si es posible\n\nGracias.\n{tecnico} · Service Desk ACCIONA'},
  pt:{title:'Solicitar mais dados do caso',body:'{saludo} {nombre|prezado(a) usuário(a)}:\n\nPara continuar com o incidente {numero}, precisamos que amplie as seguintes informações:\n\n· Descrição exata do erro\n· Quando começou a ocorrer\n· Se afeta outros colegas\n· Prints da tela, se possível\n\nObrigado.\n{tecnico} · Service Desk ACCIONA'},
  en:{title:'Request more case details',body:'{saludo} {nombre|dear user}:\n\nTo continue with incident {numero}, we need you to provide the following information:\n\n· Exact error description\n· When it started happening\n· Whether it affects colleagues\n· Screenshots if possible\n\nThank you.\n{tecnico} · ACCIONA Service Desk'}},
 {id:'intento-llamada',cat:'llamada',
  es:{title:'Intento de llamada sin éxito',body:'{saludo} {nombre|estimado/a usuario/a}:\n\nHemos intentado contactarle en el {telefono} en relación con la incidencia {numero} sin éxito. ¿Podría indicarnos un horario en el que podamos localizarle?\n\nGracias.\n{tecnico} · Service Desk ACCIONA'},
  pt:{title:'Tentativa de chamada sem sucesso',body:'{saludo} {nombre|prezado(a) usuário(a)}:\n\nTentámos contatá-lo(a) no número {telefono} em relação ao incidente {numero} sem sucesso. Poderia indicar-nos um horário em que possamos localizá-lo(a)?\n\nObrigado.\n{tecnico} · Service Desk ACCIONA'},
  en:{title:'Failed call attempt',body:'{saludo} {nombre|dear user}:\n\nWe tried to reach you at {telefono} regarding incident {numero} without success. Could you let us know a time when we can reach you?\n\nThank you.\n{tecnico} · ACCIONA Service Desk'}},
 {id:'recordatorio',cat:'seguimiento',
  es:{title:'Recordatorio de la incidencia',body:'{saludo} {nombre|estimado/a usuario/a}:\n\nLe recordamos que la incidencia {numero} sigue pendiente. ¿Podría confirmarnos si el problema persiste o si podemos proceder al cierre?\n\nGracias.\n{tecnico} · Service Desk ACCIONA'},
  pt:{title:'Lembrete do incidente',body:'{saludo} {nombre|prezado(a) usuário(a)}:\n\nRecordamos que o incidente {numero} continua pendente. Pode confirmar se o problema persiste ou se podemos proceder ao encerramento?\n\nObrigado.\n{tecnico} · Service Desk ACCIONA'},
  en:{title:'Incident reminder',body:'{saludo} {nombre|dear user}:\n\nWe remind you that incident {numero} is still pending. Could you confirm if the problem persists or if we can proceed with closing it?\n\nThank you.\n{tecnico} · ACCIONA Service Desk'}},
 {id:'escalar',cat:'escalado',
  es:{title:'Comunicar escalado a otro grupo',body:'{saludo} {nombre|estimado/a usuario/a}:\n\nTras las comprobaciones iniciales, la incidencia {numero} requiere la intervención de un equipo especializado. Vamos a proceder a su escalado y le mantendremos informado del progreso.\n\nGracias.\n{tecnico} · Service Desk ACCIONA'},
  pt:{title:'Comunicar escalonamento para outro grupo',body:'{saludo} {nombre|prezado(a) usuário(a)}:\n\nApós as verificações iniciais, o incidente {numero} requer a intervenção de uma equipe especializada. Vamos proceder com o escalonamento e manteremos você informado sobre o progresso.\n\nObrigado.\n{tecnico} · Service Desk ACCIONA'},
  en:{title:'Inform about escalation',body:'{saludo} {nombre|dear user}:\n\nAfter initial checks, incident {numero} requires intervention from a specialised team. We will proceed with its escalation and keep you informed.\n\nThank you.\n{tecnico} · ACCIONA Service Desk'}},
 {id:'cierre',cat:'cierre',
  es:{title:'Cierre de ticket',body:'{saludo} {nombre|estimado/a usuario/a}:\n\nAl confirmarse que la incidencia {numero} ha quedado resuelta, procedemos al cierre.\n\nUn saludo,\n{tecnico} · Service Desk ACCIONA'},
  pt:{title:'Encerramento do ticket',body:'{saludo} {nombre|prezado(a) usuário(a)}:\n\nConfirmado que o incidente {numero} foi resolvido, procedemos ao encerramento.\n\nAtenciosamente,\n{tecnico} · Service Desk ACCIONA'},
  en:{title:'Ticket closure',body:'{saludo} {nombre|dear user}:\n\nAs incident {numero} has been confirmed as resolved, we are proceeding with its closure.\n\nBest regards,\n{tecnico} · ACCIONA Service Desk'}}
];

// A lista ativa preserva as plantillas incorporadas e pode receber fontes partilhadas/pessoais.
var TEMPLATES=BUILTIN_TEMPLATES.slice();

var LANGS=[['es','ES'],['pt','PT'],['en','EN']];

/* ============================================================
   LISTA COMPLETA DE PAISES  (~100)
   [Nombres|Aliases, ISO, DialCode, TimeZone, Flag]
   ============================================================ */
var COUNTRIES=[
 // ---- Europa ----
 ['España|Spain|Espana','ES','34','Europe/Madrid','🇪🇸'],
 ['Portugal','PT','351','Europe/Lisbon','🇵🇹'],
 ['Alemania|Germany|Deutschland','DE','49','Europe/Berlin','🇩🇪'],
 ['Francia|France','FR','33','Europe/Paris','🇫🇷'],
 ['Italia|Italy','IT','39','Europe/Rome','🇮🇹'],
 ['Reino Unido|United Kingdom|UK|Great Britain|Inglaterra','GB','44','Europe/London','🇬🇧'],
 ['Irlanda|Ireland','IE','353','Europe/Dublin','🇮🇪'],
 ['Países Bajos|Paises Bajos|Netherlands|Holanda','NL','31','Europe/Amsterdam','🇳🇱'],
 ['Bélgica|Belgica|Belgium','BE','32','Europe/Brussels','🇧🇪'],
 ['Suiza|Switzerland|Suisse','CH','41','Europe/Zurich','🇨🇭'],
 ['Austria','AT','43','Europe/Vienna','🇦🇹'],
 ['Suecia|Sweden','SE','46','Europe/Stockholm','🇸🇪'],
 ['Noruega|Norway','NO','47','Europe/Oslo','🇳🇴'],
 ['Dinamarca|Denmark','DK','45','Europe/Copenhagen','🇩🇰'],
 ['Finlandia|Finland','FI','358','Europe/Helsinki','🇫🇮'],
 ['Polonia|Poland','PL','48','Europe/Warsaw','🇵🇱'],
 ['Grecia|Greece','GR','30','Europe/Athens','🇬🇷'],
 ['Turquía|Turquia|Turkey','TR','90','Europe/Istanbul','🇹🇷'],
 ['Rusia|Russia','RU','7','Europe/Moscow','🇷🇺'],
 ['Rumanía|Rumania|Romania','RO','40','Europe/Bucharest','🇷🇴'],
 ['República Checa|Republica Checa|Czech Republic|Czechia|Chequia','CZ','420','Europe/Prague','🇨🇿'],
 ['Hungría|Hungria|Hungary','HU','36','Europe/Budapest','🇭🇺'],
 ['Ucrania|Ukraine','UA','380','Europe/Kiev','🇺🇦'],
 ['Luxemburgo|Luxembourg','LU','352','Europe/Luxembourg','🇱🇺'],
 ['Malta','MT','356','Europe/Malta','🇲🇹'],
 ['Chipre|Cyprus','CY','357','Asia/Nicosia','🇨🇾'],
 ['Islandia|Iceland','IS','354','Atlantic/Reykjavik','🇮🇸'],
 ['Croacia|Croatia','HR','385','Europe/Zagreb','🇭🇷'],
 ['Serbia','RS','381','Europe/Belgrade','🇷🇸'],
 ['Bulgaria','BG','359','Europe/Sofia','🇧🇬'],
 ['Eslovaquia|Slovakia','SK','421','Europe/Bratislava','🇸🇰'],
 ['Eslovenia|Slovenia','SI','386','Europe/Ljubljana','🇸🇮'],

 // ---- América del Norte / Central / Caribe ----
 ['Estados Unidos|United States|USA|US','US','1','America/New_York','🇺🇸'],
 ['Canadá|Canada','CA','1','America/Toronto','🇨🇦'],
 ['México|Mexico','MX','52','America/Mexico_City','🇲🇽'],
 ['Panamá|Panama','PA','507','America/Panama','🇵🇦'],
 ['Costa Rica','CR','506','America/Costa_Rica','🇨🇷'],
 ['Guatemala','GT','502','America/Guatemala','🇬🇹'],
 ['Honduras','HN','504','America/Tegucigalpa','🇭🇳'],
 ['Nicaragua','NI','505','America/Managua','🇳🇮'],
 ['El Salvador','SV','503','America/El_Salvador','🇸🇻'],
 ['Belice|Belize','BZ','501','America/Belize','🇧🇿'],
 ['República Dominicana|Republica Dominicana|Dominican Republic','DO','1','America/Santo_Domingo','🇩🇴'],
 ['Cuba','CU','53','America/Havana','🇨🇺'],
 ['Puerto Rico','PR','1','America/Puerto_Rico','🇵🇷'],
 ['Jamaica','JM','1','America/Jamaica','🇯🇲'],
 ['Haití|Haiti','HT','509','America/Port-au-Prince','🇭🇹'],
 ['Trinidad y Tobago|Trinidad and Tobago','TT','1','America/Port_of_Spain','🇹🇹'],
 ['Bahamas','BS','1','America/Nassau','🇧🇸'],
 ['Barbados','BB','1','America/Barbados','🇧🇧'],

 // ---- América del Sur ----
 ['Brasil|Brazil','BR','55','America/Sao_Paulo','🇧🇷'],
 ['Argentina','AR','54','America/Argentina/Buenos_Aires','🇦🇷'],
 ['Chile','CL','56','America/Santiago','🇨🇱'],
 ['Colombia','CO','57','America/Bogota','🇨🇴'],
 ['Perú|Peru','PE','51','America/Lima','🇵🇪'],
 ['Ecuador','EC','593','America/Guayaquil','🇪🇨'],
 ['Bolivia','BO','591','America/La_Paz','🇧🇴'],
 ['Paraguay','PY','595','America/Asuncion','🇵🇾'],
 ['Uruguay','UY','598','America/Montevideo','🇺🇾'],
 ['Venezuela','VE','58','America/Caracas','🇻🇪'],
 ['Guyana','GY','592','America/Guyana','🇬🇾'],
 ['Surinam|Suriname','SR','597','America/Paramaribo','🇸🇷'],

 // ---- Oriente Medio ----
 ['Catar|Qatar|Katar','QA','974','Asia/Qatar','🇶🇦'],
 ['Arabia Saudí|Arabia Saudi|Saudi Arabia|Arabia Saudita','SA','966','Asia/Riyadh','🇸🇦'],
 ['Emiratos Árabes Unidos|Emiratos Arabes Unidos|United Arab Emirates|UAE|Dubái|Dubai','AE','971','Asia/Dubai','🇦🇪'],
 ['Kuwait','KW','965','Asia/Kuwait','🇰🇼'],
 ['Omán|Oman','OM','968','Asia/Muscat','🇴🇲'],
 ['Baréin|Barein|Bahrain','BH','973','Asia/Bahrain','🇧🇭'],
 ['Jordania|Jordan','JO','962','Asia/Amman','🇯🇴'],
 ['Líbano|Libano|Lebanon','LB','961','Asia/Beirut','🇱🇧'],
 ['Israel','IL','972','Asia/Jerusalem','🇮🇱'],
 ['Irán|Iran','IR','98','Asia/Tehran','🇮🇷'],
 ['Irak|Iraq','IQ','964','Asia/Baghdad','🇮🇶'],
 ['Siria|Syria','SY','963','Asia/Damascus','🇸🇾'],
 ['Yemen','YE','967','Asia/Aden','🇾🇪'],

 // ---- Asia-Pacífico ----
 ['India','IN','91','Asia/Kolkata','🇮🇳'],
 ['China','CN','86','Asia/Shanghai','🇨🇳'],
 ['Japón|Japon|Japan','JP','81','Asia/Tokyo','🇯🇵'],
 ['Corea del Sur|South Korea|Korea|Corea','KR','82','Asia/Seoul','🇰🇷'],
 ['Singapur|Singapore','SG','65','Asia/Singapore','🇸🇬'],
 ['Malasia|Malaysia','MY','60','Asia/Kuala_Lumpur','🇲🇾'],
 ['Indonesia','ID','62','Asia/Jakarta','🇮🇩'],
 ['Tailandia|Thailand','TH','66','Asia/Bangkok','🇹🇭'],
 ['Vietnam|Viet Nam','VN','84','Asia/Ho_Chi_Minh','🇻🇳'],
 ['Filipinas|Philippines','PH','63','Asia/Manila','🇵🇭'],
 ['Pakistán|Pakistan','PK','92','Asia/Karachi','🇵🇰'],
 ['Bangladesh','BD','880','Asia/Dhaka','🇧🇩'],
 ['Nepal','NP','977','Asia/Kathmandu','🇳🇵'],
 ['Sri Lanka','LK','94','Asia/Colombo','🇱🇰'],
 ['Myanmar|Birmania','MM','95','Asia/Yangon','🇲🇲'],
 ['Camboya|Cambodia','KH','855','Asia/Phnom_Penh','🇰🇭'],
 ['Laos','LA','856','Asia/Vientiane','🇱🇦'],
 ['Mongolia','MN','976','Asia/Ulaanbaatar','🇲🇳'],
 ['Kazajistán|Kazajistan|Kazakhstan','KZ','7','Asia/Almaty','🇰🇿'],
 ['Uzbekistán|Uzbekistan','UZ','998','Asia/Tashkent','🇺🇿'],
 ['Australia','AU','61','Australia/Sydney','🇦🇺'],
 ['Nueva Zelanda|New Zealand','NZ','64','Pacific/Auckland','🇳🇿'],
 ['Fiyi|Fiji','FJ','679','Pacific/Fiji','🇫🇯'],

 // ---- África ----
 ['Marruecos|Morocco','MA','212','Africa/Casablanca','🇲🇦'],
 ['Argelia|Algeria','DZ','213','Africa/Algiers','🇩🇿'],
 ['Túnez|Tunez|Tunisia','TN','216','Africa/Tunis','🇹🇳'],
 ['Egipto|Egypt','EG','20','Africa/Cairo','🇪🇬'],
 ['Sudáfrica|Sudafrica|South Africa','ZA','27','Africa/Johannesburg','🇿🇦'],
 ['Nigeria','NG','234','Africa/Lagos','🇳🇬'],
 ['Kenia|Kenya','KE','254','Africa/Nairobi','🇰🇪'],
 ['Senegal','SN','221','Africa/Dakar','🇸🇳'],
 ['Ghana','GH','233','Africa/Accra','🇬🇭'],
 ['Angola','AO','244','Africa/Luanda','🇦🇴'],
 ['Mozambique','MZ','258','Africa/Maputo','🇲🇿'],
 ['Tanzania','TZ','255','Africa/Dar_es_Salaam','🇹🇿'],
 ['Etiopía|Etiopia|Ethiopia','ET','251','Africa/Addis_Ababa','🇪🇹'],
 ['Costa de Marfil|Ivory Coast','CI','225','Africa/Abidjan','🇨🇮'],
 ['Camerún|Camerun|Cameroon','CM','237','Africa/Douala','🇨🇲'],
 ['Togo','TG','228','Africa/Lome','🇹🇬'],
 ['Benín|Benin','BJ','229','Africa/Porto-Novo','🇧🇯'],
 ['Burkina Faso','BF','226','Africa/Ouagadougou','🇧🇫'],
 ['Malí|Mali','ML','223','Africa/Bamako','🇲🇱'],
 ['Níger|Niger','NE','227','Africa/Niamey','🇳🇪'],
 ['Chad','TD','235','Africa/Ndjamena','🇹🇩'],
 ['Gabón|Gabon','GA','241','Africa/Libreville','🇬🇦'],
 ['República del Congo|Congo','CG','242','Africa/Brazzaville','🇨🇬'],
 ['República Democrática del Congo|RD Congo|DRC','CD','243','Africa/Kinshasa','🇨🇩'],
 ['Ruanda|Rwanda','RW','250','Africa/Kigali','🇷🇼'],
 ['Uganda','UG','256','Africa/Kampala','🇺🇬'],
 ['Zambia','ZM','260','Africa/Lusaka','🇿🇲'],
 ['Zimbabue|Zimbabwe','ZW','263','Africa/Harare','🇿🇼'],
 ['Botsuana|Botswana','BW','267','Africa/Gaborone','🇧🇼'],
 ['Namibia','NA','264','Africa/Windhoek','🇳🇦'],
 ['Mauricio|Mauritius','MU','230','Indian/Mauritius','🇲🇺'],
 ['Sudán|Sudan','SD','249','Africa/Khartoum','🇸🇩'],
 ['Libia|Libya','LY','218','Africa/Tripoli','🇱🇾'],
 ['Madagascar','MG','261','Indian/Antananarivo','🇲🇬'],
 ['Somalia','SO','252','Africa/Mogadishu','🇸🇴'],
 ['Sierra Leona|Sierra Leone','SL','232','Africa/Freetown','🇸🇱'],
 ['Liberia','LR','231','Africa/Monrovia','🇱🇷'],
 ['Guinea','GN','224','Africa/Conakry','🇬🇳'],
 ['Guinea-Bisáu|Guinea-Bissau','GW','245','Africa/Bissau','🇬🇼'],
 ['Gambia','GM','220','Africa/Banjul','🇬🇲'],
 ['Mauritania','MR','222','Africa/Nouakchott','🇲🇷'],
 ['Eritrea','ER','291','Africa/Asmara','🇪🇷'],
 ['Yibuti|Djibouti','DJ','253','Africa/Djibouti','🇩🇯'],
 ['Malaui|Malawi','MW','265','Africa/Blantyre','🇲🇼'],
 ['Suazilandia|Eswatini','SZ','268','Africa/Mbabane','🇸🇿'],
 ['Lesoto|Lesotho','LS','266','Africa/Maseru','🇱🇸']
];

function findCountry(v){
  if(!v)return null;
  var t=' '+norm(v).replace(/[^a-z ]/g,' ').replace(/\s+/g,' ')+' ';
  for(var i=0;i<COUNTRIES.length;i++){
    var c=COUNTRIES[i], ns=c[0].split('|');
    for(var j=0;j<ns.length;j++){
      var name=norm(ns[j]);
      if(!name)continue;
      if(t.indexOf(' '+name+' ')!==-1)return c;
    }
  }
  return null;
}
function buildDial(raw,code){
  var n=String(raw||'').trim();
  if(!n)return'';
  var plus=n.charAt(0)==='+';
  n=n.replace(/\D/g,'');
  if(plus)return'00'+n;
  if(n.indexOf('00')===0)return n;
  if(!code||code==='34')return n;
  if(n.indexOf(code)===0)return'00'+n;
  return'00'+code+n.replace(/^0+/,'');
}

var fields={},country=null,dialNumber='';
var KB=[],KB_DF={},KB_READY=false;
var tplLang='es', tplCat='all', tplQuery='', theme='light';
var fontFamily='system', fontSize=14;
var clockTz=null, clockInt=null;
// Preferências e dados por ticket ficam isolados no armazenamento da extensão.
var favorites={}, usage={}, callAttempts={}, reminderState=null;
var kbSuggestedFor='', lastAutoKbQuery='';
var deeplCorrectionTimer=null, deeplCorrectionSeq=0, deeplLastChecked='';
var deeplSuggestion=null;

function walk(w,cb,d){
  d=d||0;
  if(d>8)return;
  try{cb(w)}catch(e){}
  var fs;try{fs=w.frames}catch(e){return}
  for(var i=0;i<fs.length;i++){try{walk(fs[i],cb,d+1)}catch(e){}}
}

function getValDoc(doc, id){
  try{
    var e = doc.getElementById(id);
    if(!e) return '';
    var t = (e.type||'').toLowerCase();
    if(t==='checkbox'||t==='radio'||t==='submit'||t==='button'||t==='file') return '';
    var v = ('value' in e && e.value != null) ? e.value : (e.textContent || '');
    v = String(v).replace(/\s+/g,' ').trim();
    if(!v) return '';
    var low = v.toLowerCase();
    if(low==='on'||low==='off'||low==='true'||low==='false'||low==='null'||low==='---') return '';
    return v;
  }catch(err){ return ''; }
}
function getSelDoc(doc, id){
  try{
    var e = doc.getElementById(id);
    if(!e || !e.selectedOptions || !e.selectedOptions[0]) return '';
    return String(e.selectedOptions[0].textContent||'').trim();
  }catch(err){ return ''; }
}
function readFromDoc(doc){
  var o = {};
  if(!doc) return o;
  o.numero       = getValDoc(doc,'sys_readonly.incident.number') || getValDoc(doc,'incident.number') || getValDoc(doc,'sys_displayValue');
  o.telefono     = getValDoc(doc,'incident.u_phone') || getValDoc(doc,'sys_original.incident.u_phone');
  o.usuario      = getValDoc(doc,'sys_display.incident.caller_id') || getValDoc(doc,'incident.caller_id_label');
  o.email        = getValDoc(doc,'sys_readonly.incident.caller_id.email') || getValDoc(doc,'incident.caller_id.email');
  o.pais         = getValDoc(doc,'incident.u_ref_country_label') || getValDoc(doc,'sys_display.incident.u_ref_country');
  o.categoria    = getValDoc(doc,'sys_display.incident.u_category')    || getValDoc(doc,'incident.u_category_label');
  o.subcategoria = getValDoc(doc,'sys_display.incident.u_subcategory') || getValDoc(doc,'incident.u_subcategory_label');
  o.grupo        = getValDoc(doc,'sys_display.incident.assignment_group');
  o.tecnico      = getValDoc(doc,'sys_display.incident.assigned_to');
  o.ubicacion    = getValDoc(doc,'sys_display.incident.location');
  o.empresa      = getValDoc(doc,'incident.company_label') || getValDoc(doc,'sys_display.incident.company');
  o.catalogo     = getValDoc(doc,'incident.u_catalog_label') || getValDoc(doc,'sys_display.incident.u_catalog');
  o.asunto       = getValDoc(doc,'sys_readonly.incident.short_description') || getValDoc(doc,'incident.short_description');
  o.descripcion  = getValDoc(doc,'sys_readonly.incident.description') || getValDoc(doc,'incident.description');
  o.estado       = getSelDoc(doc,'incident.state');
  o.fecha        = new Date().toLocaleString('es-ES');
  try{
    var u = String(o.usuario||'').trim();
    if(u){
      if(u.indexOf(',')!==-1) u = (u.split(',')[1] || u).trim();
      var first = u.split(/\s+/)[0] || '';
      if(first) o.nombre = first;
    }
  }catch(e){}
  return o;
}
function readFields(){
  var o = {};
  walk(window, function(w){
    var d; try{ d = w.document; }catch(e){ return; }
    var x = readFromDoc(d);
    for(var k in x){ if(!o[k] && x[k]) o[k] = x[k]; }
  });
  return o;
}
function dumpAllFields(){
  var out = [];
  walk(window, function(w){
    var d; try{ d = w.document; }catch(e){ return; }
    try{
      var nodes = d.querySelectorAll('input,select,textarea');
      for(var i=0;i<nodes.length;i++){
        var e = nodes[i];
        var t = (e.type||'').toLowerCase();
        if(t==='checkbox'||t==='radio'||t==='submit'||t==='button'||t==='file') continue;
        var id = e.id||e.name||'';
        if(!id) continue;
        var v = ('value' in e) ? e.value : '';
        if(e.tagName==='SELECT' && e.selectedOptions && e.selectedOptions[0]) v = e.selectedOptions[0].textContent||v;
        v = String(v||'').replace(/\s+/g,' ').trim();
        if(!v || v.length<2) continue;
        var low = v.toLowerCase();
        if(low==='on'||low==='off'||low==='true'||low==='false'||low==='null'||low==='---') continue;
        var line = id+' = '+v;
        if(out.indexOf(line)===-1) out.push(line);
      }
    }catch(e){}
  });
  return out;
}
function scanCountry(){
  var ids = ['incident.u_ref_country_label','sys_display.incident.u_ref_country',
             'incident.u_ref_country','incident.u_country_label',
             'sys_display.incident.u_country','incident.location.country'];
  var r = '';
  walk(window, function(w){
    if(r) return;
    var d; try{ d = w.document; }catch(e){ return; }
    for(var i=0;i<ids.length;i++){
      var v = getValDoc(d, ids[i]);
      if(v && findCountry(v)){ r = v; return; }
    }
  });
  return r;
}

function setClockCountry(c){
  clockTz = c ? (c[3] || null) : null;
  updateClock();
  if(clockTz && !clockInt){
    clockInt = setInterval(updateClock, 1000);
  } else if(!clockTz && clockInt){
    clearInterval(clockInt); clockInt = null;
  }
}
function updateClock(){
  var el = document.getElementById('sh19-clock');
  if(!el) return;
  if(!clockTz){ el.classList.remove('on'); return; }
  try{
    var now = new Date();
    var time = now.toLocaleTimeString('es-ES', { timeZone: clockTz, hour:'2-digit', minute:'2-digit' });
    var day  = now.toLocaleDateString('es-ES', { timeZone: clockTz, weekday:'short' }).replace('.','').toUpperCase();
    var c = country || findCountry(fields.pais);
    var flag = c ? c[4] : '🌐';
    el.classList.add('on');
    el.innerHTML = '<span class="clock-flag">'+flag+'</span>'+
                   '<span class="clock-ico">🕐</span>'+
                   '<b>'+time+'</b>'+
                   '<span class="clock-day">'+day+'</span>';
    el.title = 'Hora local del solicitante · '+clockTz;
  }catch(e){ el.classList.remove('on'); }
}

function getTicketHour(tz){
  try{
    var value=new Intl.DateTimeFormat('en-GB',{timeZone:tz||undefined,hour:'2-digit',hourCycle:'h23'}).format(new Date());
    return parseInt(value,10);
  }catch(e){ return new Date().getHours(); }
}
function getGreeting(lang,tz){
  var hour=getTicketHour(tz);
  var part=hour>=6&&hour<12?'morning':(hour>=12&&hour<20?'afternoon':'night');
  var words={
    es:{morning:'Buenos días',afternoon:'Buenas tardes',night:'Buenas noches'},
    pt:{morning:'Bom dia',afternoon:'Boa tarde',night:'Boa noite'},
    en:{morning:'Good morning',afternoon:'Good afternoon',night:'Good evening'}
  };
  return (words[lang]||words.es)[part];
}
function templateData(lang){
  var data={}, key;
  for(key in fields)data[key]=fields[key];
  var tz=(country&&country[3])||clockTz||null;
  data.saludo=getGreeting(lang||tplLang,tz);
  return data;
}

function fill(t,d){
  return t.replace(/\{([^}|]+)(?:\|([^}]*))?\}/g,function(m,k,def){
    var v = d[k.trim().toLowerCase()];
    if(v) return v;
    if(def) return def;
    return '—';
  });
}
function targetField(){
  var r=null;
  walk(window,function(w){
    if(r)return;
    var d;try{d=w.document}catch(e){return}
    var sels=['#activity-stream-textarea','#activity-stream-comments-textarea',
              "textarea[data-stream-text-input='comments']",'textarea.sn-string-textarea'];
    for(var i=0;i<sels.length;i++){var e=d.querySelector(sels[i]);if(e){r=e;break}}
  });
  return r;
}
function fallbackCopy(text,done){
  var ta=document.createElement('textarea');
  ta.value=text;ta.style.position='fixed';ta.style.opacity='0';ta.style.pointerEvents='none';
  document.body.appendChild(ta);ta.select();
  try{document.execCommand('copy');done&&done()}catch(e){}
  ta.remove();
}
function copyText(text,btn){
  if(!text)return;
  var done=function(){
    toast('Copiado');
    if(btn){ btn.classList.add('copied'); clearTimeout(btn._t); btn._t=setTimeout(function(){btn.classList.remove('copied')},1400); }
  };
  if(navigator.clipboard&&navigator.clipboard.writeText){
    navigator.clipboard.writeText(text).then(done).catch(function(){fallbackCopy(text,done)});
  } else fallbackCopy(text,done);
}
function insertText(text){
  var e=targetField();
  if(!e){copyText(text,null);toast('Campo no encontrado · texto copiado');return}
  var w=e.ownerDocument.defaultView;
  var set=Object.getOwnPropertyDescriptor(w.HTMLTextAreaElement.prototype,'value').set;
  set.call(e,(e.value?e.value+'\n\n':'')+text);
  e.dispatchEvent(new w.Event('input',{bubbles:true}));
  e.dispatchEvent(new w.Event('change',{bubbles:true}));
  e.focus();
  toast('Texto insertado');
}
function dialNum(n){
  if(!n){toast('Sin número para llamar');return}
  var url='tel:'+n;
  try{ var a=document.createElement('a'); a.href=url; a.style.display='none'; document.body.appendChild(a); a.click(); setTimeout(function(){a.remove()},1200); }catch(e){}
  try{window.location.href=url}catch(e){}
  toast('Llamando '+n);
}
function toast(m){
  var e=document.getElementById('sh19-toast');
  if(!e){e=document.createElement('div');e.id='sh19-toast';document.body.appendChild(e)}
  e.textContent=m;e.classList.add('show');
  clearTimeout(e._t);e._t=setTimeout(function(){e.classList.remove('show')},2600);
}
function esc(t){ return String(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

var SVG={
 search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
 close:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>',
 phone:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
 doc:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="13" y2="17"/></svg>',
 book:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
 moon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="ico-moon"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>',
 sun:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="ico-sun"><circle cx="12" cy="12" r="4"/><line x1="12" y1="2" x2="12" y2="4"/><line x1="12" y1="20" x2="12" y2="22"/><line x1="4.93" y1="4.93" x2="6.34" y2="6.34"/><line x1="17.66" y1="17.66" x2="19.07" y2="19.07"/><line x1="2" y1="12" x2="4" y2="12"/><line x1="20" y1="12" x2="22" y2="12"/><line x1="4.93" y1="19.07" x2="6.34" y2="17.66"/><line x1="17.66" y1="6.34" x2="19.07" y2="4.93"/></svg>',
 copy:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="ico-copy"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
 check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="ico-check"><polyline points="20 6 9 17 4 12"/></svg>'
};

var STOP=new Set('de la el en y a los las un una que con por para es se su del al o e no lo como mas pero sus le ya este si porque esta entre cuando muy sin sobre tambien me hasta hay donde quien desde todo nos durante todos uno les ni contra otros ese eso ante ellos esto mi antes algunos unos yo otro otras otra tanto esa estos mucho quienes nada muchos cual poco ella estar estas algunas algo nosotros the of and to in is for on with as at by an be this that it from or your you'.split(' '));
function tok(s){return norm(s).replace(/[^a-z0-9ñ ]/g,' ').split(/\s+/).filter(function(w){return w.length>2&&!STOP.has(w)})}
// Pequeno glossário de consulta para aproximar termos PT dos artigos indexados em ES.
var KB_PT_ALIASES={
  'caixa de correio':'buzon correo', 'correio':'correo', 'email':'correo',
  'palavra passe':'contrasena', 'palavra-passe':'contrasena', 'senha':'contrasena',
  'impressora':'impresora', 'ficheiro':'archivo', 'arquivo':'archivo',
  'rede':'red', 'acesso':'acceso', 'aceder':'acceso', 'partilhada':'compartido',
  'partilhado':'compartido', 'computador':'ordenador', 'telemovel':'movil',
  'telemóvel':'movil', 'atualizacao':'actualizacion', 'atualização':'actualizacion',
  'bloqueado':'bloqueado', 'nao consigo':'no puedo'
};
function expandKbQuery(query){
  var original=String(query||'');
  if(detectLang(original)!=='pt')return original;
  var n=norm(original), extra=[];
  Object.keys(KB_PT_ALIASES).forEach(function(term){
    if(n.indexOf(norm(term))!==-1)extra.push(KB_PT_ALIASES[term]);
  });
  return original+' '+extra.join(' ');
}
async function loadKB(){
 try{
  var cfg=await new Promise(function(r){chrome.storage.local.get({kbUrl:''},r)});
  var url=(cfg.kbUrl&&cfg.kbUrl.trim())?cfg.kbUrl.trim():chrome.runtime.getURL('kb-base.json');
  var res=await fetch(url);var data=await res.json();
  KB=(data.items||data).map(function(k){return {n:k.n,c:k.c,t:k.t,e:k.e,toks:tok((k.n||'')+' '+(k.c||'')+' '+(k.t||''))}});
  KB_DF={};KB.forEach(function(k){new Set(k.toks).forEach(function(t){KB_DF[t]=(KB_DF[t]||0)+1})});
  KB_READY=true;updateKbBadge();
 }catch(e){KB_READY=false}
}
function kbSearch(query,topK){
 if(!KB.length)return[];
 var N=KB.length;
 var idf=function(t){return Math.log((N+1)/((KB_DF[t]||0)+1))+1};
 function vec(toks){var tf={};toks.forEach(function(t){tf[t]=(tf[t]||0)+1});
  var v={},n2=0;for(var t in tf){var w=tf[t]*idf(t);v[t]=w;n2+=w*w}
  var m=Math.sqrt(n2)||1;for(var t2 in v)v[t2]/=m;return v}
 var qv=vec(tok(expandKbQuery(query)));
 var scored=KB.map(function(k){var av=vec(k.toks),dot=0;
  for(var t in qv)if(av[t])dot+=qv[t]*av[t];
  return {k:k,score:dot}});
 scored.sort(function(a,b){return b.score-a.score});
 return scored.filter(function(s){return s.score>0.02}).slice(0,topK||8).map(function(s){
  return {n:s.k.n,c:s.k.c,t:s.k.t,e:s.k.e}});
}
function updateKbBadge(){var b=document.querySelector('#sh19-kbn');if(b)b.textContent=(KB.length||0)+' KBs'}

var COUNTRY_TO_LANG={ES:'es',MX:'es',PE:'es',AR:'es',CO:'es',CL:'es',UY:'es',PY:'es',BO:'es',EC:'es',VE:'es',CR:'es',PA:'es',GT:'es',DO:'es',BR:'pt',PT:'pt',AO:'pt',MZ:'pt',CV:'pt',US:'en',GB:'en',AU:'en',CA:'en',IN:'en',CN:'en',JP:'en',DE:'en',FR:'en',IT:'en',PH:'en',SG:'en',ZA:'en',NG:'en',KE:'en',AE:'en',SA:'en',QA:'en'};
function detectLang(text){
 var t=String(text||'').toLowerCase();
 var s={es:0,pt:0,en:0};
 var h={
  pt:['não','nao','você','voce','olá','ola','obrigado','obrigada','incidente','erro','também','tambem','solicito','ajuda','está','bloqueado','mesmo','compartilhado'],
  es:['no puedo','no consigo','hola','gracias','necesito','ayuda','incidencia','estoy','saludos','encontrar','usuario','error','compartido'],
  en:['cannot','hello','thank you','please','need help','incident','ticket','issue','problem','unable','shared','mailbox','blocked']
 };
 for(var l in h)for(var i=0;i<h[l].length;i++){var w=h[l][i];if(t.indexOf(w)!==-1)s[l]+=w.indexOf(' ')!==-1?3:1}
 var b='es',m=-1;for(var l2 in s)if(s[l2]>m){m=s[l2];b=l2}
 return m>0?b:null;
}
function pickTemplateLang(){
  var fromText=detectLang((fields.descripcion||'')+' '+(fields.asunto||''));
  if(fromText)return fromText;
  var c=findCountry(fields.pais);
  return c?(COUNTRY_TO_LANG[c[1]]||'es'):'es';
}

function normaliseTemplate(raw,index,source){
  if(!raw||typeof raw!=='object')return null;
  var id=String(raw.id||((source||'template')+'-'+index)).replace(/[^a-z0-9_-]/gi,'-').toLowerCase();
  var cat=String(raw.cat||raw.category||'info').toLowerCase();
  if(!CATS[cat])cat='info';
  var out={id:id,cat:cat};
  var fallbackTitle=raw.title||raw.name||'';
  var fallbackBody=raw.body||raw.text||'';
  var any=false;
  ['es','pt','en'].forEach(function(lang){
    var item=raw[lang];
    if(typeof item==='string')item={body:item};
    item=item&&typeof item==='object'?item:{};
    var title=String(item.title||fallbackTitle||'Plantilla compartida').trim();
    var body=String(item.body||item.text||fallbackBody||'').trim();
    if(body){out[lang]={title:title,body:body};any=true;}
  });
  return any?out:null;
}
function mergeTemplates(shared,personal){
  var result=BUILTIN_TEMPLATES.slice(), byId={};
  result.forEach(function(t,i){byId[t.id]=i;});
  function merge(list,source){
    (Array.isArray(list)?list:[]).forEach(function(raw,i){
      var t=normaliseTemplate(raw,i,source);
      if(!t)return;
      if(Object.prototype.hasOwnProperty.call(byId,t.id))result[byId[t.id]]=t;
      else {byId[t.id]=result.length;result.push(t);}
    });
  }
  merge(shared,'shared');
  merge(personal,'personal');
  TEMPLATES=result;
}
async function loadTemplates(){
  try{
    var local=await new Promise(function(resolve){chrome.storage.local.get({templatesUrl:''},resolve);});
    var sync=await new Promise(function(resolve){chrome.storage.sync.get({templates:[]},resolve);});
    var shared=[];
    if(local.templatesUrl&&String(local.templatesUrl).trim()){
      try{
        var response=await fetch(String(local.templatesUrl).trim());
        var data=await response.json();
        shared=Array.isArray(data)?data:(data.items||data.templates||[]);
      }catch(e){toast('No se pudieron cargar las plantillas compartidas');}
    }
    mergeTemplates(shared,sync.templates);
  }catch(e){ mergeTemplates([],[]); }
  if(typeof renderTplCatChips==='function'){renderTplCatChips();renderTemplates();}
}

var FONT_STACKS={
 system:'ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI Variable", "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
 inter:'"Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif',
 segoe:'"Segoe UI Variable Text", "Segoe UI", ui-sans-serif, system-ui, -apple-system, sans-serif',
 roboto:'"Roboto", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Arial, sans-serif',
 ibm:'"IBM Plex Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif',
 mono:'ui-monospace, "JetBrains Mono", "SF Mono", "Cascadia Code", "Roboto Mono", Consolas, monospace'
};
function applyTheme(t){
 theme=t;
 document.documentElement.setAttribute('data-sh-theme',t);
 try{chrome.storage.local.set({shTheme:t})}catch(e){}
}
function applyFont(family,size){
  fontFamily=family||fontFamily||'system';
  fontSize=size||fontSize||14;
  var r=document.documentElement.style;
  r.setProperty('--ui-font',FONT_STACKS[fontFamily]||FONT_STACKS.system);
  r.setProperty('--fs-2xs',(fontSize*0.72).toFixed(2)+'px');
  r.setProperty('--fs-xs',(fontSize*0.79).toFixed(2)+'px');
  r.setProperty('--fs-sm',(fontSize*0.86).toFixed(2)+'px');
  r.setProperty('--fs-md',(fontSize*0.93).toFixed(2)+'px');
  r.setProperty('--fs-base',fontSize+'px');
  r.setProperty('--fs-lg',(fontSize*1.07).toFixed(2)+'px');
  r.setProperty('--fs-xl',(fontSize*1.16).toFixed(2)+'px');
  try{chrome.storage.local.set({shFontFamily:fontFamily,shFontSize:fontSize})}catch(e){}
}

function rankKey(kind,item){return kind+':'+(kind==='tpl'?item.id:item.n);}
function isFavorite(key){return !!favorites[key];}
function rankItems(items,kind){
  return items.map(function(item,index){return {item:item,index:index,key:rankKey(kind,item)};}).sort(function(a,b){
    var af=isFavorite(a.key)?1:0,bf=isFavorite(b.key)?1:0;
    if(af!==bf)return bf-af;
    var au=Number(usage[a.key]||0),bu=Number(usage[b.key]||0);
    if(au!==bu)return bu-au;
    return a.index-b.index;
  }).map(function(x){return x.item;});
}
function favoriteButton(key){
  return '<button class="favorite-btn'+(isFavorite(key)?' active':'')+'" data-favorite="'+esc(key)+'" title="'+(isFavorite(key)?'Quitar de favoritos':'Añadir a favoritos')+'">'+(isFavorite(key)?'★':'☆')+'</button>';
}
function bindFavoriteButton(card,key,rerender){
  var button=card.querySelector('[data-favorite]');
  if(!button)return;
  button.onclick=function(e){
    e.stopPropagation();
    if(isFavorite(key))delete favorites[key];else favorites[key]=true;
    try{chrome.storage.local.set({shFavorites:favorites});}catch(err){}
    rerender();
  };
}
function recordUse(key){
  usage[key]=Number(usage[key]||0)+1;
  try{chrome.storage.local.set({shUsage:usage});}catch(e){}
}
function loadUsageData(){
  try{chrome.storage.local.get({shFavorites:{},shUsage:{},shCallAttempts:{}},function(data){
    favorites=data.shFavorites&&typeof data.shFavorites==='object'?data.shFavorites:{};
    usage=data.shUsage&&typeof data.shUsage==='object'?data.shUsage:{};
    callAttempts=data.shCallAttempts&&typeof data.shCallAttempts==='object'?data.shCallAttempts:{};
    if(typeof renderTemplates==='function'){renderTplCatChips();renderTemplates();}
    if(typeof renderCallAttemptStatus==='function')renderCallAttemptStatus();
  });}catch(e){}
}
function ticketStorageKey(){
  return String(fields.numero||('page:'+location.pathname.replace(/[^a-z0-9]/gi,'-'))).slice(0,140);
}
function attemptCount(){
  var attempts=callAttempts[ticketStorageKey()];
  return Array.isArray(attempts)?attempts.length:0;
}
function ticketTime(){
  try{return new Intl.DateTimeFormat('es-ES',{timeZone:(country&&country[3])||clockTz||undefined,hour:'2-digit',minute:'2-digit'}).format(new Date());}
  catch(e){return new Date().toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'});}
}
function attemptLabel(){
  return ({es:'Intento de llamada',pt:'Tentativa de chamada',en:'Call attempt'})[tplLang]||'Intento de llamada';
}
function registerCallAttempt(){
  var key=ticketStorageKey(), attempts=Array.isArray(callAttempts[key])?callAttempts[key].slice():[];
  var count=attempts.length+1;
  insertText(attemptLabel()+' #'+count+' · '+ticketTime());
  attempts.push({at:Date.now()});
  callAttempts[key]=attempts.slice(-12);
  try{chrome.storage.local.set({shCallAttempts:callAttempts});}catch(e){}
  renderCallAttemptStatus();renderTemplates();
  if(count===3){
    tplCat='llamada';activateTab('templates');renderTplCatChips();renderTemplates();
    toast('3º intento registrado · plantilla sugerida');
  }else toast('Intento '+count+' registrado');
}
function renderCallAttemptStatus(){
  var el=$('#sh19-attempt-status');if(!el)return;
  var count=attemptCount();
  el.textContent=count?'Intentos registrados en este ticket: '+count:'Todavía no hay intentos registrados para este ticket.';
  var b=$('#sh19-register-attempt');if(b)b.textContent='Registrar intento'+(count?' ('+count+')':'');
}
function reminderLabel(){
  if(!reminderState)return '';
  var date=new Date(reminderState.when||0);
  return isNaN(date.getTime())?'':'Aviso programado para '+date.toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'});
}
function renderReminderControls(){
  var box=$('#sh19-reminder');if(!box)return;
  var state=norm(fields.estado||'');
  var waiting=state.indexOf('esper')!==-1||state.indexOf('aguard')!==-1||state.indexOf('wait')!==-1||state.indexOf('hold')!==-1;
  box.innerHTML='<div class="quick-title">Aguardando usuário'+(waiting?'':' · lembrete manual')+'</div>'+
   '<div class="reminder-row"><select id="sh19-reminder-delay"><option value="30">30 minutos</option><option value="60">1 hora</option></select>'+
   '<button id="sh19-set-reminder" class="accent">Lembrar</button>'+(reminderState?'<button id="sh19-cancel-reminder" class="ghost">Cancelar</button>':'')+'</div>'+
   '<small>'+esc(reminderLabel()||'Receba uma notificação do Chrome para este ticket.')+'</small>';
  var set=$('#sh19-set-reminder');
  if(set)set.onclick=function(){
    var delay=Number($('#sh19-reminder-delay').value||30), ticket=ticketStorageKey();
    try{chrome.runtime.sendMessage({type:'snow-helper:set-reminder',ticket:ticket,number:fields.numero||ticket,user:fields.usuario||'',url:location.href,delay:delay},function(res){
      if(chrome.runtime.lastError||!res||!res.ok){toast('No se pudo programar el aviso');return;}
      reminderState=res.reminder||null;renderReminderControls();toast('Aviso programado');
    });}catch(e){toast('No se pudo programar el aviso');}
  };
  var cancel=$('#sh19-cancel-reminder');
  if(cancel)cancel.onclick=function(){
    try{chrome.runtime.sendMessage({type:'snow-helper:clear-reminder',ticket:ticketStorageKey()},function(res){
      if(chrome.runtime.lastError||!res||!res.ok){toast('No se pudo cancelar el aviso');return;}
      reminderState=null;renderReminderControls();toast('Aviso cancelado');
    });}catch(e){}
  };
}
function loadReminderState(){
  try{chrome.runtime.sendMessage({type:'snow-helper:get-reminder',ticket:ticketStorageKey()},function(res){
    if(chrome.runtime.lastError)return;
    reminderState=res&&res.reminder||null;renderReminderControls();
  });}catch(e){}
}

var root=document.createElement('div');
root.id='snowhelper19-root';
root.innerHTML=
'<button id="sh19-callfloat" title="Llamar">'+SVG.phone+'<small id="sh19-iso"></small></button>'+
'<button id="sh19-open" title="SNOW Helper"><span class="toolmark">\u2726</span></button>'+
'<section id="sh19-panel" class="hidden">'+
 '<header>'+
  '<div class="h-left"><span class="logo">S</span>'+
   '<div class="h-text"><b>SNOW Helper</b><small id="sh19-ticket">Service Desk</small></div>'+
  '</div>'+
  '<div id="sh19-clock" title="Hora local del solicitante"></div>'+
  '<div class="header-tools">'+
   '<button id="sh19-debug-btn" class="tool-btn aa" title="Campos detectados"><span>?</span></button>'+
   '<button id="sh19-settings-btn" class="tool-btn aa" title="Apariencia"><span>Aa</span></button>'+
   '<button id="sh19-theme" class="tool-btn" title="Modo oscuro">'+SVG.moon+SVG.sun+'</button>'+
   '<button id="sh19-close" class="tool-btn" title="Cerrar">'+SVG.close+'</button>'+
  '</div>'+
 '</header>'+
 '<nav id="sh19-nav">'+
  '<button class="active" data-tab="templates">'+SVG.doc+'<span>Plantillas</span></button>'+
  '<button data-tab="kb">'+SVG.book+'<span>KBs</span></button>'+
  '<button data-tab="call">'+SVG.phone+'<span>Llamar</span></button>'+
 '</nav>'+
 '<div id="sh19-context">\u2014</div>'+
 '<main id="sh19-main">'+
  '<div id="tab-templates" class="tab">'+
   '<div class="userinfo" id="sh19-userinfo"></div>'+
   '<div id="sh19-translate" class="translate-panel"></div>'+
   '<div id="sh19-suggestions"></div>'+
   '<div id="sh19-reminder" class="reminder-panel"></div>'+
   '<div class="chips-row" id="sh19-lang-chips"><span class="row-lbl">Idioma</span></div>'+
   '<div class="chips-row" id="sh19-cat-chips"><span class="row-lbl">Categoría</span></div>'+
   '<div class="search-bar"><div class="search-field">'+
    '<input id="sh19-tplq" placeholder="Buscar plantillas\u2026" autocomplete="off">'+
    '<button class="search-clear" id="sh19-tplclear">'+SVG.close+'</button>'+
   '</div></div>'+
   '<div id="sh19-tpllist"></div>'+
  '</div>'+
  '<div id="tab-kb" class="tab hidden">'+
   '<div class="search-bar"><div class="search-field">'+
    '<input id="sh19-kbq" placeholder="Buscar en las KBs\u2026 ej: buzón, outlook, mfa" autocomplete="off">'+
    '<button class="search-clear" id="sh19-kbclear">'+SVG.close+'</button>'+
   '</div><button class="search-go" id="sh19-kbgo">'+SVG.search+'</button></div>'+
   '<span id="sh19-kbn" class="kb-badge">… KBs</span>'+
   '<span id="sh19-kb-auto" class="kb-auto hidden"></span>'+
   '<div id="sh19-kbres"></div>'+
  '</div>'+
  '<div id="tab-call" class="tab hidden">'+
   '<div class="callcard"><div id="sh19-flag" class="flag">\uD83C\uDF10</div>'+
    '<div><small>País detectado</small><b id="sh19-countryname">No detectado</b></div>'+
   '</div>'+
   '<label>Teléfono</label><input id="sh19-phone" placeholder="Escribe o pega un número...">'+
   '<label>Número preparado para MicroSIP</label>'+
   '<div style="display:flex;gap:8px;margin-bottom:12px">'+
    '<input id="sh19-number" readonly style="margin:0;flex:1">'+
    '<button id="sh19-copy-number" class="tool-btn" title="Copiar número" style="width:auto;height:auto;padding:0 14px;border:1px solid var(--bd);background:var(--bg)">Copiar</button>'+
   '</div>'+
   '<select id="sh19-countryselect"></select>'+
   '<button id="sh19-callmain" class="callmain">'+SVG.phone+' Llamar ahora</button>'+
   '<button id="sh19-register-attempt" class="callattempt">Registrar intento</button>'+
   '<div id="sh19-attempt-status" class="attempt-status"></div>'+
  '</div>'+
 '</main>'+
'</section>';
document.body.appendChild(root);

var modal=document.createElement('div');
modal.id='sh19-modal';modal.className='hidden';
modal.innerHTML=
 '<div class="modal-backdrop"></div>'+
 '<div class="modal-panel" role="dialog" aria-modal="true">'+
  '<header><div class="m-left"><div class="m-logo" id="sh19-modal-logo">'+SVG.doc+'</div>'+
   '<div class="m-text"><b id="sh19-modal-title">\u2014</b><small id="sh19-modal-cat">\u2014</small></div></div>'+
   '<button id="sh19-modal-close">'+SVG.close+'</button>'+
  '</header>'+
  '<div class="modal-body"><pre id="sh19-modal-text"></pre></div>'+
  '<footer><span class="meta" id="sh19-modal-meta"></span>'+
   '<button id="sh19-modal-copy">Copiar</button>'+
   '<button id="sh19-modal-insert" class="accent">Insertar</button>'+
  '</footer>'+
 '</div>';
document.body.appendChild(modal);

var settings=document.createElement('div');
settings.id='sh19-settings';settings.className='hidden';
settings.innerHTML=
 '<div class="st-title">Apariencia</div>'+
 '<div class="st-row"><label>Fuente</label>'+
  '<select id="sh19-font-family">'+
   '<option value="system">Sistema (recomendado)</option>'+
   '<option value="inter">Inter</option>'+
   '<option value="segoe">Segoe UI</option>'+
   '<option value="roboto">Roboto</option>'+
   '<option value="ibm">IBM Plex Sans</option>'+
   '<option value="mono">JetBrains Mono</option>'+
  '</select>'+
 '</div>'+
 '<div class="st-row"><label>Tamaño <span class="st-val" id="sh19-font-size-val">14 px</span></label>'+
  '<input type="range" id="sh19-font-size" min="12" max="18" step="1" value="14">'+
 '</div>';
document.body.appendChild(settings);

var $=function(s){return root.querySelector(s)};
var $$=function(s){return root.querySelectorAll(s)};
var panel=$('#sh19-panel');
var modalState={open:false,panelWasVisible:false,currentText:'',currentKey:''};

$('#sh19-theme').onclick=function(){applyTheme(theme==='dark'?'light':'dark')};

function openSettings(){
 var r=panel.getBoundingClientRect();
 settings.style.top=(r.top+62)+'px';
 settings.style.right=Math.max(12, window.innerWidth-r.right+18)+'px';
 settings.classList.remove('hidden');
 updateRangeFill();
}
function closeSettings(){settings.classList.add('hidden')}
$('#sh19-settings-btn').onclick=function(e){
 e.stopPropagation();
 if(settings.classList.contains('hidden'))openSettings(); else closeSettings();
};
document.addEventListener('click',function(e){
 if(settings.classList.contains('hidden'))return;
 if(settings.contains(e.target))return;
 var b=document.getElementById('sh19-settings-btn');
 if(b&&b.contains(e.target))return;
 closeSettings();
});
window.addEventListener('resize',function(){if(!settings.classList.contains('hidden'))openSettings()});

var fontSel=settings.querySelector('#sh19-font-family');
var fontRng=settings.querySelector('#sh19-font-size');
var fontVal=settings.querySelector('#sh19-font-size-val');
function updateRangeFill(){
 var min=parseInt(fontRng.min,10),max=parseInt(fontRng.max,10);
 var v=parseInt(fontRng.value,10);
 fontRng.style.setProperty('--p',((v-min)/(max-min))*100+'%');
}
fontSel.addEventListener('change',function(){applyFont(fontSel.value,parseInt(fontRng.value,10))});
fontRng.addEventListener('input',function(){
 var v=parseInt(fontRng.value,10);
 fontVal.textContent=v+' px';
 updateRangeFill();
 applyFont(fontSel.value,v);
});

function openModal(opts){
 modalState.panelWasVisible=!panel.classList.contains('hidden');
  modalState.open=true;
  modalState.currentText=opts.text||'';
  modalState.currentKey=opts.usageKey||'';
 document.getElementById('sh19-modal-title').textContent=opts.title||'';
 document.getElementById('sh19-modal-cat').textContent=opts.subtitle||'';
 document.getElementById('sh19-modal-meta').textContent=opts.meta||'';
 document.getElementById('sh19-modal-text').textContent=opts.text||'';
 var logo=document.getElementById('sh19-modal-logo');
 logo.innerHTML=opts.icon==='book'?SVG.book:(opts.icon==='phone'?SVG.phone:SVG.doc);
 logo.classList.toggle('blue',opts.accent==='blue');
 if(modalState.panelWasVisible){
  panel.classList.add('panel-mini');
  setTimeout(function(){panel.classList.add('hidden')},180);
 }
 modal.classList.remove('hidden');
 setTimeout(function(){document.getElementById('sh19-modal-close').focus()},180);
}
function closeModal(){
 if(!modalState.open)return;
 modalState.open=false;
 modal.classList.add('hidden');
 if(modalState.panelWasVisible){
  setTimeout(function(){
   panel.classList.remove('hidden');
   panel.classList.remove('panel-mini');
  },180);
 }
}
document.getElementById('sh19-modal-close').onclick=closeModal;
modal.querySelector('.modal-backdrop').onclick=closeModal;
modal.addEventListener('click',function(e){if(e.target===modal)closeModal()});
document.getElementById('sh19-modal-copy').onclick=function(){
 if(modalState.currentKey)recordUse(modalState.currentKey);
 copyText(modalState.currentText,null);
};
document.getElementById('sh19-modal-insert').onclick=function(){
 var t=modalState.currentText;
 if(modalState.currentKey)recordUse(modalState.currentKey);
 closeModal();
 setTimeout(function(){insertText(t)},220);
};

$('#sh19-debug-btn').onclick=function(e){
 e.stopPropagation();
 var all=dumpAllFields();
 var lines=[];
 lines.push('=== CAMPOS DETECTADOS PELO EXTENSION ===');
 var keys=['numero','usuario','nombre','telefono','email','pais','empresa','ubicacion','catalogo','categoria','subcategoria','grupo','tecnico','estado','asunto'];
 for(var i=0;i<keys.length;i++){
  var k=keys[i];
  lines.push(k+': '+(fields[k]||'(vazio)'));
 }
 lines.push('');
 lines.push('=== TODOS OS CAMPOS NA PAGINA (id = valor) ===');
 if(!all.length)lines.push('(nada encontrado)');
 else for(var j=0;j<all.length;j++)lines.push(all[j]);
 var txt=lines.join('\n');
 openModal({
  title:'Debug · '+all.length+' campos',
  subtitle:'Diagnostico',
  text:txt,icon:'doc',
  meta:'Paises disponibles: '+COUNTRIES.length
 });
};

function activateTab(name){
 var btns=$$('#sh19-nav button');
 for(var i=0;i<btns.length;i++)btns[i].classList.toggle('active',btns[i].getAttribute('data-tab')===name);
 var tabs=$$('.tab');
 for(var j=0;j<tabs.length;j++)tabs[j].classList.toggle('hidden',tabs[j].id!=='tab-'+name);
 if(name==='kb')runAutoKbSuggestions();
}

$('#sh19-open').onclick=function(){
 if(panel.classList.contains('hidden')){
  panel.classList.remove('hidden');
  activateTab('templates');
  setTimeout(refresh,60);
  setTimeout(refresh,800);
  setTimeout(refresh,2000);
 } else {
  panel.classList.add('hidden');
 }
};
$('#sh19-close').onclick=function(){closeSettings();panel.classList.add('hidden')};

$$('#sh19-nav button').forEach(function(b){
 b.onclick=function(){
  var name=b.getAttribute('data-tab');
  activateTab(name);
  var tab=$('#tab-'+name);
  if(tab){tab.style.animation='none';void tab.offsetWidth;tab.style.animation=''}
 };
});

var cs=$('#sh19-countryselect');
COUNTRIES.forEach(function(c){
 var o=document.createElement('option');
 o.value=c[2];o.textContent=c[4]+' '+c[0].split('|')[0]+' (+'+c[2]+')';
 cs.appendChild(o);
});
function updateCall(){
 dialNumber=buildDial($('#sh19-phone').value,cs.value);
 $('#sh19-number').value=dialNumber;
 var fb=$('#sh19-callfloat');
 fb.classList.remove('hidden');
 fb.classList.toggle('empty',!dialNumber);
 var sel=cs.selectedOptions[0];
 $('#sh19-iso').textContent=sel?sel.textContent.slice(0,2):'';
}
$('#sh19-phone').oninput=updateCall;
cs.onchange=function(){
 var o=cs.selectedOptions[0];
 $('#sh19-countryname').textContent=o?o.textContent.slice(3):'';
 var code=cs.value;
 var matched=null;
 for(var i=0;i<COUNTRIES.length;i++) if(COUNTRIES[i][2]===code){ matched=COUNTRIES[i]; break; }
 if(matched) setClockCountry(matched);
 updateCall();
};
$('#sh19-copy-number').onclick=function(){copyText(dialNumber||$('#sh19-phone').value,null)};
$('#sh19-callfloat').onclick=function(){
 if(!dialNumber){
  if(panel.classList.contains('hidden')){
   panel.classList.remove('hidden');
   activateTab('call');
  } else { activateTab('call'); }
  setTimeout(function(){var ph=$('#sh19-phone');if(ph)ph.focus()},80);
  toast('Escribe un número para llamar');
  return;
 }
 dialNum(dialNumber);
};
$('#sh19-callmain').onclick=function(){dialNum(dialNumber)};
$('#sh19-register-attempt').onclick=registerCallAttempt;

function renderUserInfo(){
 var el=$('#sh19-userinfo');
 var f=fields||{};
 var items=[];
 if(f.numero)      items.push({l:'Incidencia',  v:f.numero});
 if(f.usuario)     items.push({l:'Solicitante', v:f.usuario, full:true});
 if(f.email)       items.push({l:'Email',       v:f.email});
 if(f.telefono)    items.push({l:'Teléfono',    v:f.telefono});
 if(f.pais)        items.push({l:'País',        v:f.pais});
 if(f.catalogo)    items.push({l:'Catálogo',    v:f.catalogo});
 if(f.empresa)     items.push({l:'Empresa',     v:f.empresa});
 if(f.ubicacion)   items.push({l:'Ubicación',   v:f.ubicacion, full:true});
 if(f.categoria)   items.push({l:'Categoría',   v:f.categoria});
 if(f.subcategoria)items.push({l:'Subcat.',     v:f.subcategoria});
 if(f.grupo)       items.push({l:'Grupo',       v:f.grupo});
 if(f.tecnico)     items.push({l:'Técnico',     v:f.tecnico});
 if(f.estado)      items.push({l:'Estado',      v:f.estado});
 if(!items.length){
  el.innerHTML='<div class="ui-title">Datos del ticket</div>'+
   '<div style="font-size:12.5px;color:var(--text-soft);line-height:1.6">'+
   'No se detectaron datos aún. Espera a que la incidencia cargue, o pulsa <b>?</b> arriba.'+
   '</div>';
  el.style.display='';
  return;
 }
 el.style.display='';
 el.innerHTML='<div class="ui-title">Datos del ticket</div><div class="ui-grid">'+
  items.map(function(it){
   return '<div class="ui-item'+(it.full?' full':'')+'">'+
    '<span class="ui-label">'+esc(it.l)+'</span>'+
    '<span class="ui-value-row">'+
     '<span class="ui-value" title="'+esc(it.v)+'">'+esc(it.v)+'</span>'+
     '<button class="ui-copy" data-copy="'+esc(it.v)+'" title="Copiar '+esc(it.l)+'">'+SVG.copy+SVG.check+'</button>'+
    '</span>'+
   '</div>';
  }).join('')+'</div>';
 var btns=el.querySelectorAll('.ui-copy');
 for(var i=0;i<btns.length;i++){
  (function(btn){
   btn.addEventListener('click',function(e){
    e.stopPropagation();
    copyText(btn.getAttribute('data-copy')||'',btn);
   });
  })(btns[i]);
 }
}

function renderTplLangChips(){
 var box=$('#sh19-lang-chips');
 var chips=box.querySelectorAll('.chip');
 for(var i=0;i<chips.length;i++)chips[i].remove();
 LANGS.forEach(function(p){
  var b=document.createElement('button');
  b.className='chip'+(tplLang===p[0]?' active':'');
  b.textContent=p[1];
  b.onclick=function(){
   tplLang=p[0];
   try{chrome.storage.local.set({shTplLang:p[0]})}catch(e){}
   renderTplLangChips();renderTemplates();
  };
  box.appendChild(b);
 });
}
function renderTplCatChips(){
 var box=$('#sh19-cat-chips');
 var chips=box.querySelectorAll('.chip');
 for(var i=0;i<chips.length;i++)chips[i].remove();
 var counts={};
 TEMPLATES.forEach(function(t){counts[t.cat]=(counts[t.cat]||0)+1});
 Object.keys(CATS).forEach(function(k){
  var n=k==='all'?TEMPLATES.length:(counts[k]||0);
  if(!n)return;
  var b=document.createElement('button');
  b.className='chip'+(tplCat===k?' active':'');
  b.innerHTML=esc(CATS[k][tplLang]||CATS[k].es)+'<span class="n">'+n+'</span>';
  b.onclick=function(){tplCat=k;renderTplCatChips();renderTemplates()};
  box.appendChild(b);
 });
}
function tplMatchCat(t){return tplCat==='all'?true:t.cat===tplCat}
function suggestedTemplate(){
 var state=norm(fields.estado||''), cat='';
 if(/nuevo|nova|new|open/.test(state))cat='apertura';
 else if(/esper|aguard|wait|hold|pend/.test(state))cat='seguimiento';
 else if(/resuelt|resolvid|resolved|closed|cerrad/.test(state))cat='cierre';
 if(!cat)return null;
 for(var i=0;i<TEMPLATES.length;i++)if(TEMPLATES[i].cat===cat)return {template:TEMPLATES[i],reason:'Sugerida por el estado: '+(fields.estado||CATS[cat].es)};
 return null;
}
function renderTemplateSuggestions(){
 var box=$('#sh19-suggestions');if(!box)return;
 var suggestions=[], byState=suggestedTemplate();
 if(byState)suggestions.push(byState);
 if(attemptCount()>=3){
  for(var i=0;i<TEMPLATES.length;i++)if(TEMPLATES[i].id==='intento-llamada'){
   suggestions.push({template:TEMPLATES[i],reason:'Sugerida tras '+attemptCount()+' intentos de llamada'});break;
  }
 }
 if(!suggestions.length){box.innerHTML='';return;}
 box.innerHTML=suggestions.map(function(item,index){
  var o=item.template[tplLang]||item.template.es;
  return '<div class="suggestion-card"><div><b>'+esc(o.title)+'</b><small>'+esc(item.reason)+'</small></div><button class="accent" data-suggest="'+index+'">Insertar</button></div>';
 }).join('');
 suggestions.forEach(function(item,index){
  var button=box.querySelector('[data-suggest="'+index+'"]');
  if(button)button.onclick=function(){
   recordUse(rankKey('tpl',item.template));
   insertText(fill((item.template[tplLang]||item.template.es).body,templateData(tplLang)));
  };
 });
}
function renderTemplates(){
 renderTemplateSuggestions();
 var q=(tplQuery||'').trim().toLowerCase();
 var box=$('#sh19-tpllist');box.innerHTML='';
 var list=TEMPLATES.filter(function(t){return tplMatchCat(t)}).filter(function(t){
  if(!q)return true;
  var o=t[tplLang]||t.es;
  return (o.title+' '+o.body).toLowerCase().indexOf(q)!==-1;
 });
 list=rankItems(list,'tpl');
 if(!list.length){ box.innerHTML='<div class="empty"><b>Sin plantillas</b>Prueba otra búsqueda o categoría.</div>'; return; }
 list.forEach(function(t,i){
  var o=t[tplLang]||t.es;
  var filled=fill(o.body,templateData(tplLang)), key=rankKey('tpl',t);
  var a=document.createElement('article');
  a.style.animationDelay=(i*40)+'ms';
  a.innerHTML='<div class="card-top"><b>'+esc(o.title)+'</b>'+favoriteButton(key)+'</div><p>'+esc(filled.slice(0,240))+(filled.length>240?'…':'')+'</p>'+
   '<div class="actions"><button class="ghost" data-act="view">Ver</button><button data-act="copy">Copiar</button><button class="accent" data-act="insert">Insertar</button></div>';
  bindFavoriteButton(a,key,renderTemplates);
  a.querySelector('[data-act="view"]').onclick=function(){
   openModal({
    title:o.title,
    subtitle:(CATS[t.cat]&&(CATS[t.cat][tplLang]||CATS[t.cat].es))||'',
    text:filled, icon:'doc', usageKey:key,
    meta:filled.length+' caracteres'
   });
  };
  a.querySelector('[data-act="copy"]').onclick=function(e){recordUse(key);copyText(filled,e.currentTarget)};
  a.querySelector('[data-act="insert"]').onclick=function(){recordUse(key);insertText(filled)};
  box.appendChild(a);
 });
}
$('#sh19-tplq').addEventListener('input',function(){
 tplQuery=$('#sh19-tplq').value;
 $('#sh19-tplclear').classList.toggle('visible',tplQuery.length>0);
 renderTemplates();
});
$('#sh19-tplclear').onclick=function(){
 var i=$('#sh19-tplq');
 i.value='';tplQuery='';i.focus();
 $('#sh19-tplclear').classList.remove('visible');
 renderTemplates();
};

function renderKbResults(list){
 var box=$('#sh19-kbres');box.innerHTML='';
 list=rankItems(list||[],'kb');
 if(!list.length){ box.innerHTML='<div class="empty"><b>Escribe para buscar</b>Busca entre las KBs de ACCIONA.</div>'; return; }
 list.forEach(function(k,i){
  var text=(k.n||'')+' — '+(k.c||'')+'\n\n'+(k.t||'')+(k.e?'\n\nEscalar a: '+k.e:'');
  var key=rankKey('kb',k), a=document.createElement('article');
  a.style.animationDelay=(i*40)+'ms';
  a.innerHTML='<div class="card-top"><b><span class="kb-num">'+esc(k.n||'')+'</span><span class="kb-cat">'+esc(k.c||'—')+'</span></b>'+favoriteButton(key)+'</div><p>'+esc(k.t||'')+'</p>'+(k.e?'<div class="kb-esc">Escalar a: '+esc(k.e)+'</div>':'')+'<div class="actions"><button class="ghost" data-act="view">Ver</button><button data-act="copy">Copiar</button><button class="accent" data-act="insert">Insertar</button></div>';
  bindFavoriteButton(a,key,function(){renderKbResults(list);});
  a.querySelector('[data-act="view"]').onclick=function(){
   openModal({ title:(k.n||'')+' · '+(k.c||''),subtitle:'Artículo de conocimiento',text:text,icon:'book',accent:'blue',usageKey:key,meta:k.e?('Escalar a '+k.e):'' });
  };
  a.querySelector('[data-act="copy"]').onclick=function(e){recordUse(key);copyText(text,e.currentTarget)};
  a.querySelector('[data-act="insert"]').onclick=function(){recordUse(key);insertText(text)};
  box.appendChild(a);
 });
}
function setKbAutoLabel(text){
 var label=$('#sh19-kb-auto');if(!label)return;
 label.textContent=text||'';label.classList.toggle('hidden',!text);
}
function buildAutoKbQuery(){
 return [fields.asunto,fields.descripcion,fields.categoria,fields.subcategoria].filter(Boolean).join(' ').slice(0,1800);
}
function runKbSearch(query,automatic){
 var q=(typeof query==='string'?query:$('#sh19-kbq').value).trim();
 if(!q){renderKbResults([]);return}
 if(!automatic)setKbAutoLabel('');
 var render=function(){renderKbResults(kbSearch(q,8));};
 if(!KB_READY){loadKB().then(render);return}
 render();
}
function runAutoKbSuggestions(){
 var q=buildAutoKbQuery(), marker=ticketStorageKey()+'|'+q;
 if(!q){setKbAutoLabel('');renderKbResults([]);return;}
 if(marker===kbSuggestedFor)return;
 kbSuggestedFor=marker;lastAutoKbQuery=q;
 setKbAutoLabel('Sugerencias automáticas · asunto y descripción del ticket');
 runKbSearch(q,true);
}
$('#sh19-kbgo').onclick=runKbSearch;
$('#sh19-kbq').addEventListener('input',function(){ $('#sh19-kbclear').classList.toggle('visible',$('#sh19-kbq').value.length>0); });
$('#sh19-kbq').addEventListener('keydown',function(e){ if(e.key==='Enter'){e.preventDefault();runKbSearch()} });
$('#sh19-kbclear').onclick=function(){ var i=$('#sh19-kbq'); i.value='';i.focus(); $('#sh19-kbclear').classList.remove('visible'); setKbAutoLabel(''); renderKbResults([]); };

function refresh(){
 fields=readFields();
 if(!fields.pais) fields.pais = scanCountry() || fields.pais || '';
 country=findCountry(fields.pais);
 $('#sh19-ticket').textContent=fields.numero||'Service Desk';
 var ctx=[fields.numero,fields.categoria,fields.pais].filter(Boolean).join(' · ');
 $('#sh19-context').textContent=ctx||'(sin datos · pulsa ? arriba)';
 $('#sh19-phone').value=fields.telefono||'';
 if(country){
  cs.value=country[2];
  $('#sh19-countryname').textContent=country[0].split('|')[0]+' (+'+country[2]+')';
  $('#sh19-flag').textContent=country[4]||'🌐';
  setClockCountry(country);
 } else {
  cs.value='34';
  $('#sh19-countryname').textContent=fields.pais?('Detectado: '+fields.pais):'No detectado';
  $('#sh19-flag').textContent='🌐';
  setClockCountry(null);
 }
 updateCall();
 renderUserInfo();
 renderTranslationPanel();
 renderTplLangChips();
 renderTplCatChips();
 renderCallAttemptStatus();
 renderReminderControls();
 loadReminderState();
 renderTemplates();
}

chrome.storage.local.get({shTheme:'light',shTplLang:null,shFontFamily:'system',shFontSize:14},function(r){
 applyTheme(r.shTheme||'light');
 applyFont(r.shFontFamily||'system',r.shFontSize||14);
 fontSel.value=fontFamily;
 fontRng.value=fontSize;
 fontVal.textContent=fontSize+' px';
 updateRangeFill();
 if(r.shTplLang)tplLang=r.shTplLang;
 refresh();
 if(!r.shTplLang){
  var auto=pickTemplateLang();
  if(auto!==tplLang){
   tplLang=auto;
   try{chrome.storage.local.set({shTplLang:auto})}catch(e){}
   renderTplLangChips();renderTemplates();
  }
 }
});
loadKB();
loadTemplates();
loadUsageData();

setTimeout(function(){ if(!country){ var c=scanCountry(); if(c){ country=findCountry(c); if(country) setClockCountry(country); } } }, 1200);

function syncAll(){
 if(panel.classList.contains('hidden'))return;
 try{
  var nf=readFields();
  var changed=false;
  // `fecha` é recalculada em cada leitura e nunca deve provocar um redraw.
  // Antes disso, o intervalo de sincronização fazia as plantillas piscarem.
  for(var k in nf){
   if(k==='fecha')continue;
   if(nf[k] && nf[k]!==fields[k]){ fields[k]=nf[k]; changed=true; }
  }
  if(!fields.pais){ var c=scanCountry(); if(c){fields.pais=c;changed=true;} }
  if(changed){
   var newCountry=findCountry(fields.pais);
   if(newCountry && (!country || newCountry[1]!==country[1])) setClockCountry(newCountry);
   country=newCountry;
   $('#sh19-ticket').textContent=fields.numero||'Service Desk';
   var ctx=[fields.numero,fields.categoria,fields.pais].filter(Boolean).join(' · ');
   $('#sh19-context').textContent=ctx||'(sin datos)';
   var ph=$('#sh19-phone'); if(ph && fields.telefono) ph.value=fields.telefono;
   if(country){
    cs.value=country[2];
    $('#sh19-countryname').textContent=country[0].split('|')[0]+' (+'+country[2]+')';
    $('#sh19-flag').textContent=country[4]||'🌐';
   } else if(fields.pais){
    $('#sh19-countryname').textContent='Detectado: '+fields.pais;
   }
   updateCall();renderUserInfo();renderTranslationPanel();renderCallAttemptStatus();renderReminderControls();loadReminderState();renderTemplates();bindDeeplCorrection();
  }
 }catch(e){}
}
setInterval(syncAll,2000);
setTimeout(syncAll,600);
setTimeout(syncAll,1500);
setTimeout(syncAll,3000);
setTimeout(bindDeeplCorrection,900);
setInterval(bindDeeplCorrection,2500);

try{
 var _t=null;
 var mo=new MutationObserver(function(records){
  // Ignora mutações causadas pelo próprio painel; elas não são alterações do ticket.
  var relevant=false;
  for(var i=0;i<records.length&&!relevant;i++){
   var node=records[i].target;
   if(node&&node.closest&&node.closest('#snowhelper19-root,#sh19-modal,#sh19-settings'))continue;
   relevant=true;
  }
  if(!relevant)return;
  clearTimeout(_t);_t=setTimeout(syncAll,300);
 });
 mo.observe(document.documentElement,{childList:true,subtree:true});
}catch(e){}


function deeplConfig(done){
 try{chrome.storage.local.get({deepLApiKey:'',deepLApiMode:'free'},function(cfg){done(cfg||{});});}
 catch(e){done({});}
}
function deeplBase(cfg){return (cfg&&cfg.deepLApiMode==='pro'?'https://api.deepl.com':'https://api-free.deepl.com');}
function deeplRequest(path,payload,done){
 deeplConfig(function(cfg){
  var key=String(cfg.deepLApiKey||'').trim();
  if(!key){done({ok:false,code:'NO_KEY'});return;}
  fetch(deeplBase(cfg)+path,{method:'POST',headers:{'Authorization':'DeepL-Auth-Key '+key,'Content-Type':'application/json'},body:JSON.stringify(payload)})
   .then(function(res){return res.json().catch(function(){return {};}).then(function(data){return {res:res,data:data};});})
   .then(function(result){
    if(!result.res.ok){done({ok:false,code:result.res.status,message:result.data.message||''});return;}
    done({ok:true,data:result.data});
   }).catch(function(){done({ok:false,code:'NETWORK'});});
 });
}
function deeplTargetFor(lang){return lang==='pt'?'pt-BR':(lang==='en'?'en-US':'es');}
function deeplCorrectionTarget(text){
 var lang=detectLang(text)||pickTemplateLang()||'es';
 return deeplTargetFor(lang);
}
function setTextareaValue(e,text){
 try{
  var w=e.ownerDocument.defaultView;
  var set=Object.getOwnPropertyDescriptor(w.HTMLTextAreaElement.prototype,'value').set;
  set.call(e,text);e.dispatchEvent(new w.Event('input',{bubbles:true}));e.dispatchEvent(new w.Event('change',{bubbles:true}));
 }catch(err){e.value=text;}
}
function removeDeeplSuggestion(){
 if(deeplSuggestion&&deeplSuggestion.parentNode)deeplSuggestion.parentNode.removeChild(deeplSuggestion);
 deeplSuggestion=null;
}
function positionDeeplSuggestion(box,field){
 var r=field.getBoundingClientRect();
 box.style.top=Math.max(8,r.bottom+8)+'px';
 box.style.left=Math.min(Math.max(8,r.left),Math.max(8,window.innerWidth-390))+'px';
}
function showDeeplSuggestion(field,original,corrected){
 removeDeeplSuggestion();
 if(!corrected||corrected.trim()===original.trim())return;
 var box=document.createElement('div');box.id='sh19-deepl-suggestion';
 box.innerHTML='<div class="deepl-suggestion-head"><b>Sugestão de correção</b><button type="button" data-deepl-close>×</button></div>'+
  '<div class="deepl-suggestion-text"></div><div class="deepl-suggestion-actions"><button type="button" data-deepl-copy>Copiar</button><button type="button" class="accent" data-deepl-apply>Aplicar</button></div>';
 box.querySelector('.deepl-suggestion-text').textContent=corrected;
 box.querySelector('[data-deepl-close]').onclick=function(){removeDeeplSuggestion();};
 box.querySelector('[data-deepl-apply]').onclick=function(){setTextareaValue(field,corrected);removeDeeplSuggestion();toast('Correção aplicada');};
 box.querySelector('[data-deepl-copy]').onclick=function(){copyText(corrected,null);};
 document.body.appendChild(box);deeplSuggestion=box;positionDeeplSuggestion(box,field);
}
function scheduleDeeplCorrection(field){
 if(!field||field.dataset.shDeeplBound==='1')return;
 field.dataset.shDeeplBound='1';
 field.addEventListener('input',function(){
  var text=String(field.value||'').trim();
  clearTimeout(deeplCorrectionTimer);removeDeeplSuggestion();
  if(text.length<24||text===deeplLastChecked)return;
  var seq=++deeplCorrectionSeq;
  deeplCorrectionTimer=setTimeout(function(){
   deeplLastChecked=text;
   deeplRequest('/v2/write/correct',{text:[text],target_lang:deeplCorrectionTarget(text)},function(result){
    if(seq!==deeplCorrectionSeq||field.value.trim()!==text)return;
    if(!result.ok){if(result.code==='NO_KEY')return;return;}
    var item=result.data&&result.data.improvements&&result.data.improvements[0];
    if(item&&item.text)showDeeplSuggestion(field,text,item.text);
   });
  },1400);
 });
}
function bindDeeplCorrection(){
 var field=targetField();if(field)scheduleDeeplCorrection(field);
}
function renderTranslationPanel(){
 var box=$('#sh19-translate');if(!box)return;
 var hasText=!!(fields.asunto||fields.descripcion);
 box.innerHTML='<div class="translate-head"><b>Traduzir ticket</b><small>Assunto e descrição</small></div>'+
  '<div class="translate-actions"><button id="sh19-translate-pt" '+(hasText?'':'disabled')+'>Português</button><button id="sh19-translate-en" '+(hasText?'':'disabled')+'>English</button></div>'+
  '<div id="sh19-translation-result" class="translation-result"></div>';
 var source=[fields.asunto,fields.descripcion].filter(Boolean).join('\n\n');
 function run(target,label){
  var result=$('#sh19-translation-result');result.classList.add('loading');result.textContent='Traduzindo para '+label+'…';
  deeplRequest('/v2/translate',{text:[source],target_lang:target},function(response){
   result.classList.remove('loading');
   if(!response.ok){result.textContent=response.code==='NO_KEY'?'Configure a chave DeepL no popup da extensão.':'Não foi possível traduzir este ticket.';return;}
   var translated=response.data&&response.data.translations&&response.data.translations[0]&&response.data.translations[0].text;
   result.innerHTML='<div class="translation-result-text"></div><div class="translation-result-actions"><button id="sh19-copy-translation">Copiar tradução</button></div>';
   result.querySelector('.translation-result-text').textContent=translated||'';
   result.querySelector('#sh19-copy-translation').onclick=function(){copyText(translated||'',null);};
  });
 }
 $('#sh19-translate-pt').onclick=function(){run('PT-BR','português');};
 $('#sh19-translate-en').onclick=function(){run('EN-US','inglês');};
}
try{chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
 if(message&&message.type==='snow-helper:open-panel'){
  panel.classList.remove('hidden');activateTab(message.tab||'templates');setTimeout(refresh,60);
  if(sendResponse)sendResponse({ok:true});
 }
});}catch(e){}

document.addEventListener('keydown',function(e){
 if(e.key==='Escape'){
  if(!settings.classList.contains('hidden')){closeSettings();return}
  if(modalState.open){closeModal();return}
  if(!panel.classList.contains('hidden')){panel.classList.add('hidden');return}
 }
});
})();
