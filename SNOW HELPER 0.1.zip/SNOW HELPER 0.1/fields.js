(function(){
'use strict';

function clean(v){ return v==null?'':String(v).replace(/\s+/g,' ').trim(); }

function getVal(doc, id){
  try{
    var e = doc.getElementById(id);
    if(!e) return '';
    var t = (e.type||'').toLowerCase();
    if(t==='checkbox'||t==='radio'||t==='submit'||t==='button'||t==='file') return '';
    var v = ('value' in e && e.value != null) ? e.value : (e.textContent || '');
    v = clean(v);
    if(!v) return '';
    var low = v.toLowerCase();
    if(low==='on'||low==='off'||low==='true'||low==='false'||low==='null'||low==='---') return '';
    return v;
  }catch(err){ return ''; }
}

function getSel(doc, id){
  try{
    var e = doc.getElementById(id);
    if(!e || !e.selectedOptions || !e.selectedOptions[0]) return '';
    return clean(e.selectedOptions[0].textContent);
  }catch(err){ return ''; }
}

function readFromDoc(doc){
  var o = {};
  if(!doc) return o;

  // IDs EXATOS retirados do HTML real da ServiceNow ACCIONA
  o.numero       = getVal(doc, 'sys_readonly.incident.number') || getVal(doc, 'incident.number');
  o.telefono     = getVal(doc, 'incident.u_phone')             || getVal(doc, 'sys_original.incident.u_phone');
  o.usuario      = getVal(doc, 'sys_display.incident.caller_id')|| getVal(doc, 'incident.caller_id_label');
  o.email        = getVal(doc, 'sys_readonly.incident.caller_id.email') || getVal(doc, 'incident.caller_id.email');
  o.pais         = getVal(doc, 'incident.u_ref_country_label') || getVal(doc, 'sys_display.incident.u_ref_country');
  o.categoria    = getVal(doc, 'sys_display.incident.u_category')    || getVal(doc, 'incident.u_category_label');
  o.subcategoria = getVal(doc, 'sys_display.incident.u_subcategory') || getVal(doc, 'incident.u_subcategory_label');
  o.grupo        = getVal(doc, 'sys_display.incident.assignment_group');
  o.tecnico      = getVal(doc, 'sys_display.incident.assigned_to');
  o.ubicacion    = getVal(doc, 'sys_display.incident.location');
  o.empresa      = getVal(doc, 'incident.company_label')             || getVal(doc, 'sys_display.incident.company');
  o.catalogo     = getVal(doc, 'incident.u_catalog_label')           || getVal(doc, 'sys_display.incident.u_catalog');
  o.asunto       = getVal(doc, 'sys_readonly.incident.short_description') || getVal(doc, 'incident.short_description');
  o.descripcion  = getVal(doc, 'sys_readonly.incident.description')  || getVal(doc, 'incident.description');
  o.estado       = getSel(doc, 'incident.state');
  o.fecha        = new Date().toLocaleString('es-ES');
  return o;
}

function readAll(){
  var o = readFromDoc(document);
  // se o documento atual for um iframe vazio, tenta no parent (same-origin)
  try{
    if(!o.numero && window.top && window.top.document && window.top.document !== document){
      var parent = readFromDoc(window.top.document);
      for(var k in parent) if(!o[k] && parent[k]) o[k] = parent[k];
    }
  }catch(e){}
  return o;
}

function dumpAll(){
  var out = [];
  try{
    var nodes = document.querySelectorAll('input,select,textarea');
    for(var i=0;i<nodes.length;i++){
      var e = nodes[i];
      var t = (e.type||'').toLowerCase();
      if(t==='checkbox'||t==='radio'||t==='submit'||t==='button'||t==='file') continue;
      var id = e.id||e.name||'';
      if(!id) continue;
      var v = ('value' in e) ? e.value : '';
      if(e.tagName==='SELECT' && e.selectedOptions && e.selectedOptions[0]){
        v = e.selectedOptions[0].textContent || v;
      }
      v = clean(v);
      if(!v || v.length<2) continue;
      var low = v.toLowerCase();
      if(low==='on'||low==='off'||low==='true'||low==='false'||low==='null'||low==='---') continue;
      out.push(id + ' = ' + v);
    }
  }catch(e){}
  return out;
}

window.__SNOWHELPER19_FIELDS__ = {
  readAllFields: readAll,
  dumpAllFields: dumpAll
};
})();
