'use strict';
var $=function(s){return document.querySelector(s)};
var DEF=[
 {title:'Contacto inicial',body:'{saludo} {nombre|estimado/a usuario/a}:\n\nLe contactamos en relación con la incidencia {numero}. ¿Puede confirmar si está disponible?\n\nUn saludo.'},
 {title:'Diagnósticos de red',body:'{saludo} {nombre}:\n\nPara avanzar con la incidencia {numero}, necesitamos ipconfig /all, ping y tracert.\n\nGracias.'}
];
var data=[];
function loadT(){chrome.storage.sync.get({templates:null},function(r){
 data=Array.isArray(r.templates)&&r.templates.length?r.templates:DEF.slice();renderT();
});}
function saveT(){chrome.storage.sync.set({templates:data},renderT);}
function renderT(){
 var l=$('#list');l.innerHTML='';
 data.forEach(function(x,i){
  var d=document.createElement('div');d.className='item';
  d.innerHTML='<b></b><small></small><div class="row"><button>Editar</button><button class="danger">Borrar</button></div>';
  d.querySelector('b').textContent=x.title;
  d.querySelector('small').textContent=x.body;
  var b=d.querySelectorAll('button');
  b[0].onclick=function(){$('#title').value=x.title;$('#body').value=x.body;data.splice(i,1);saveT();};
  b[1].onclick=function(){data.splice(i,1);saveT();};
  l.appendChild(d);
 });
}
function validUrl(value){
 if(!value)return true;
 try{var url=new URL(value);return url.protocol==='https:'||url.protocol==='http:';}catch(e){return false;}
}
function showStatus(text,error){
 var el=$('#source-status');el.textContent=text;el.classList.toggle('error',!!error);el.classList.add('show');
 clearTimeout(el._timer);el._timer=setTimeout(function(){el.classList.remove('show');},2600);
}
function loadSources(){chrome.storage.local.get({kbUrl:'',templatesUrl:''},function(r){
 $('#kb-url').value=r.kbUrl||'';$('#templates-url').value=r.templatesUrl||'';
});}
function loadDeepL(){chrome.storage.local.get({deepLApiKey:'',deepLApiMode:'free'},function(r){
 $('#deepl-key').value=r.deepLApiKey||'';$('#deepl-mode').value=r.deepLApiMode||'free';
});}
function deeplStatus(text,error){var el=$('#deepl-status');el.textContent=text;el.classList.toggle('error',!!error);el.classList.add('show');clearTimeout(el._timer);el._timer=setTimeout(function(){el.classList.remove('show');},2600);}
$('#save-deepl').onclick=function(){
 var key=$('#deepl-key').value.trim(),mode=$('#deepl-mode').value||'free';
 if(!key){deeplStatus('Cole uma chave DeepL válida.',true);return;}
 chrome.storage.local.set({deepLApiKey:key,deepLApiMode:mode},function(){deeplStatus('Chave DeepL guardada localmente.');});
};
$('#clear-deepl').onclick=function(){chrome.storage.local.remove(['deepLApiKey','deepLApiMode'],function(){$('#deepl-key').value='';$('#deepl-mode').value='free';deeplStatus('Chave apagada.');});};
function loadShortcut(){
 chrome.commands.getAll(function(commands){
  var command=commands.filter(function(item){return item.name==='toggle-panel';})[0];
  $('#shortcut').textContent=command&&command.shortcut?command.shortcut:'No asignado';
 });
}
$('#save').onclick=function(){
 if(!$('#body').value.trim())return;
 data.push({title:$('#title').value||'Sin título',body:$('#body').value});
 $('#title').value='';$('#body').value='';saveT();
};
$('#reset').onclick=function(){data=DEF.slice();saveT();};
$('#save-sources').onclick=function(){
 var kb=$('#kb-url').value.trim(),templates=$('#templates-url').value.trim();
 if(!validUrl(kb)||!validUrl(templates)){showStatus('Usa una URL http(s) válida.',true);return;}
 chrome.storage.local.set({kbUrl:kb,templatesUrl:templates},function(){showStatus('URLs guardadas. Recarga ServiceNow para aplicarlas.');});
};
$('#open-shortcuts').onclick=function(){chrome.tabs.create({url:'chrome://extensions/shortcuts'});};
loadT();loadSources();loadDeepL();loadShortcut();
